var array = [ [7,[[8],9]], [4,5,6], [1,[],3]]
console.log(array);